<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('head'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/custom/ad-post.css'), false); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?> 
    <section class="adpost-part">
        <div class="container">
           <h1>Membership section</h1>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/dashboard/membership.blade.php ENDPATH**/ ?>