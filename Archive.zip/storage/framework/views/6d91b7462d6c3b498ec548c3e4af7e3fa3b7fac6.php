<div class="product-card">
    <div class="product-media">
        <div class="product-img"><img src="<?php echo e($item->get_thumbnail(), false); ?>" alt="product"></div>
        <div class="product-type"><span class="flat-badge sale">sale</span></div>
        <ul class="product-action">
            <li class="view"><i class="fas fa-eye"></i><span>264</span></li>
            <li class="click"><i class="fas fa-mouse"></i><span>134</span></li>
            <li class="rating"><i class="fas fa-star"></i><span>4.5/7</span></li>
        </ul>
    </div>
    <div class="product-content">
        <ol class="breadcrumb product-category">
            <li><i class="fas fa-tags"></i></li>
            <li class="breadcrumb-item"><a href="#"><?php echo e($item->category->name, false); ?></a></li>
        </ol>
        <h5 class="product-title"><a href="<?= URL::asset('/') ?><?php echo e($item->slug, false); ?>"><?php echo e($item->get_name_short(), false); ?></a></h5>
        <div class="product-meta"><span><i class="fas fa-map-marker-alt"></i><?php echo e($item->country->name, false); ?>,
                <?php echo e($item->city->name, false); ?></span><span><i
                    class="fas fa-clock"></i><?php echo e($item->created_at->diffForHumans(), false); ?></span></div>
        <div class="product-info">
            <h5 class="product-price">$<?php echo e(number_format($item->price,0), false); ?><span>/<?php if($item->fixed_price): ?>
                    Fixed
                    <?php else: ?>
                    Negotiable
                    <?php endif; ?></span></h5>
            <div class="product-btn">
                <a href="<?= URL::asset('/') ?><?php echo e($item->slug, false); ?>" title="Compare" class="fas fa-compress"></a><button type="button"
                    title="Wishlist" class="far fa-heart"></button>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/components/product1.blade.php ENDPATH**/ ?>