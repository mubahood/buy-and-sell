<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('head'); ?>
<link rel="stylesheet" href="<?php echo e(URL::asset('/assets/css/custom/my-ads.css'), false); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
use Illuminate\Support\Facades\Auth;
use App\Models\Product;
$user_id = Auth::id();
$products = Product::where('user_id', $user_id)->get();
?>


<?php echo $__env->make('layouts.dashboard-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<section class="myads-part">
    <div class="container">

        <?php if(count($products)<1): ?> <div class="container">
            <div class="row justify-content-center">
                <div class="col-12 col-lg-8 ">
                    <div class="card dash-header-card pt-0">
                        <div class="card-body text-center">

                            <img src="<?= URL::asset('assets/') ?>/images/empty-box.png" width="120"
                                alt="empty-box.png">

                            <h2 class="h4 text-center mt-4">You don't have any service yet.</h2>
                            <p class="text-center">Click the "Post servicee" now button to post your service.</p>
                            <a href="<?= URL::asset('/post-ad') ?>" class="btn btn-inline mt-4 mb-2 post-btn"><i
                                    class="fas fa-plus-circle"></i><span>post your service</span></a>
                        </div>
                    </div>
                </div>
            </div>
    </div>
    <?php else: ?>




    <div class="row">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-md-6 col-lg-4 col-xl-3">
            <div class="product-card">
                <div class="product-media">
                    <div class="product-img"><img src="<?php echo e($item->get_thumbnail(), false); ?>" alt="<?php echo e($item->get_thumbnail(), false); ?>">
                    </div>
                    <div class="cross-vertical-badge product-badge"><i class="fas fa-fire"></i><span>top
                            niche</span></div>
                    <div class="product-type"><span class="flat-badge booking">new</span></div>
                    <ul class="product-action">
                        <li class="view"><i class="fas fa-eye"></i><span>264</span></li>
                        <li class="click"><i class="fas fa-mouse"></i><span>134</span></li>
                        <li class="rating"><i class="fas fa-star"></i><span>4.5/7</span></li>
                    </ul>
                </div>
                <div class="product-content">
                    <ol class="breadcrumb product-category">
                        <li><i class="fas fa-tags"></i></li>
                        <li class="breadcrumb-item"><a href="#">Luxury</a></li>
                        <li class="breadcrumb-item active" aria-current="page">resort</li>
                    </ol>
                    <h5 class="product-title"><a href="ad-details-left.html"><?php echo e($item->name, false); ?></a></h5>
                    <div class="product-meta"><span><i class="fas fa-map-marker-alt"></i><?php echo e($item->category->name, false); ?>,
                            <?php echo e($item->category->name, false); ?></span><span><i
                                class="fas fa-clock"></i><?php echo e($item->updated_at, false); ?></span></div>
                    <div class="product-info">
                        <h5 class="product-price">$<?php echo e($item->price, false); ?><span>/starting price</span></h5>
                        <div class="product-btn">
                            <a href="#" title="Delete" class="fas fa-trash text-danger"></a><button type="button"
                                title="Edit" class="far fa-edit"></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/mac/Desktop/Github/buy-and-sell/resources/views/dashboard/index.blade.php ENDPATH**/ ?>